Classes Complete:

					Transaction
					Funds
					Activity
					Event
					Person
					Volunteer
					Student
					Member
					Calendar
					Utility



Unit Tests Complete:

					EventTest
					MemberTest
					TransactionTest
					UtilityTest
