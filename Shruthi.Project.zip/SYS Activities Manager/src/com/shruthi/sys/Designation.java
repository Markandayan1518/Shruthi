package com.shruthi.sys;

/**
 * @author Shruthi
 *
 */
public enum Designation  {
	TREASURER, PRHEAD, GENERAL, PRESIDENT
}
